package com.javaProject.JavaProject.controller;

public class ValidationController {
}
