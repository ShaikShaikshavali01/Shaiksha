package com.javaProject.JavaProject.service;



import com.javaProject.JavaProject.dto.CustomerDto;

public interface CustomerService {
    CustomerDto registerCustomer(CustomerDto customerDto);
}