package com.javaProject.JavaProject.service;



public interface EmailService {
    void sendOtpEmail(String email, String otp);
}
